package org.lpro.tokenjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokenJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(TokenJwtApplication.class, args);
	}

}

