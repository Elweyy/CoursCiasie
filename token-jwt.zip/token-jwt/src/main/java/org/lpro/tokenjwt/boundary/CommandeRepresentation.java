package org.lpro.tokenjwt.boundary;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;
import java.util.Optional;
import javax.servlet.ServletException;
import org.lpro.tokenjwt.entity.Commande;
import org.lpro.tokenjwt.entity.JwtResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@RequestMapping("/commandes")
public class CommandeRepresentation {

    @PostMapping(value = "/token")
    public JwtResponse token(@RequestBody Commande commande) throws ServletException {

        String jwtToken;

        jwtToken = Jwts.builder().setSubject(commande.getCmdId()).claim("roles", "commande").setIssuedAt(new Date())
                .signWith(SignatureAlgorithm.HS256, "secretkey").compact();

        return new JwtResponse(jwtToken);
    }

    @GetMapping(value = "/1234")
    public String validCommand(@RequestHeader(value = "x-lbs-token") String headerToken) {
        return headerToken;
    }

}
