package org.lpro.tokenjwt.entity;

import java.util.Date;
import org.hibernate.annotations.CreationTimestamp;

public class Commande {

    private String cmdId;
    private String commandName;

    @CreationTimestamp
    private Date created;

    public String getCmdId() {
        return cmdId;
    }

    public void setCmdId(String cmdId) {
        this.cmdId = cmdId;
    }

    public String getCommandName() {
        return commandName;
    }

    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
